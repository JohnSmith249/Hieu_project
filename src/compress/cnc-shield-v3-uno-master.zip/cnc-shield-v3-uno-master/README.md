# cnc-shield-v3-uno
Arduino CNC Shield V3 + DRV8825

[![Maker Tutor](https://img.youtube.com/vi/DZcrrFcs4N4/0.jpg)](https://www.youtube.com/watch?v=DZcrrFcs4N4)
